from django.contrib import admin

from .models import ToDoList

class TaskAdmin(admin.ModelAdmin):
    readonly_fields = ('created_on',)

admin.site.register(ToDoList, TaskAdmin)