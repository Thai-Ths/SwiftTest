from rest_framework import routers

from .viewsets import ToDoViewSet

app_name = "task"

router = routers.DefaultRouter()
router.register('todolist', ToDoViewSet)