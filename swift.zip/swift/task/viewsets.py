from rest_framework import viewsets, mixins, filters
from .serializers import ToDoSerializer
from rest_framework.response import Response
from rest_framework import status

from django_filters.rest_framework import DjangoFilterBackend
from .models import ToDoList
from rest_framework.decorators import action
from task import serializers

class ToDoViewSet(viewsets.ModelViewSet):
    queryset = ToDoList.objects.all()
    serializer_class = ToDoSerializer
    filter_backends =[filters.SearchFilter, DjangoFilterBackend]
    search_fields = ['description', 'status', ]
    filterset_fields = ['status', ]

   
