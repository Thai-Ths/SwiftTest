from django.contrib import admin

from .models import SendMail

admin.site.register(SendMail)